﻿using System;
/*
Arrays

1. What functionality does a "for" block provide that a "foreach" does not?
  The for block iterates through until condition = true, while the foreach block can iterate in a list or array like when you have a list of items it directy accesses each element in that list.

2. What is the primary advantage of jagged arrays over a multidimensional array (i.e., one created using the new int[4, 2] syntax)?
Its about efficiency and memory consumption.  It can also store data in a multidimensional way using the same variable name which helps in memory management which helps the program to be excuted smoothly and fast. 
-eduCBAwww.educba.com 

Apply

Enumerations and Structures

Declare an enum with underlying type short and at least three legal values.
*/
namespace JeffBHW7GArrayEnumstructs
{
    enum GameCodes : short
    {
        Lives = 2313,
        Ammo = 2314,
        Shields = 2315,
        Life = 2316
    };

}
